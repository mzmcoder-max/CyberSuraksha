# CyberSuraksha

A simple browser-based prototype for Digital Safety & Cyber Fraud Awareness.

## Features
- Checks suspicious messages for common scam warning signs
- Gives Low, Medium or High Risk guidance
- Simple interface for students, senior citizens and first-time digital users
- No login and no server-side storage

## Run
Open `index.html` in a modern browser.

## Files
- `index.html` - interface
- `style.css` - design
- `script.js` - risk-checking logic
- `docs/ARCHITECTURE.md` - technical design
- `sample_data/scam_examples.csv` - sample data
- `tests/test_cases.md` - test cases
- `LICENSE` - MIT License

This is an awareness prototype, not a certified fraud-detection system.
