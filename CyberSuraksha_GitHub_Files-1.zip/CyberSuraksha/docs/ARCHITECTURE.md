# CyberSuraksha Architecture

User -> Web UI -> JavaScript rule checker -> Risk result -> Safety guidance

Technology: HTML5, CSS3 and Vanilla JavaScript.

The current prototype processes entered text locally in the browser and does not send it to a server.

Future scope: Hindi and Indian-language support, URL reputation checks, voice guidance, official reporting links and validated ML-based classification.
