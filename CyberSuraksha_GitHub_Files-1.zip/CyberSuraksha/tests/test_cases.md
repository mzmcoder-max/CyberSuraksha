# Test Cases

1. OTP request -> High/Medium risk
2. CVV or UPI PIN request -> High/Medium risk
3. Lottery/prize message -> Medium/High risk
4. Urgent payment request -> Medium/High risk
5. Normal appointment message -> Low risk
6. Empty input -> Validation message
